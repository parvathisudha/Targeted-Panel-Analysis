# build-common
Common build scripts used in C/C++ projects. Intended to make compiling with CMake and handling dependencies slightly easier.
